#!/bin/sh

echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::            JXMOBILE BY TOANDAIK SERVER STARTING            :::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo "::                      FileServer starting                     ::"
nohup ./FileServer_NUMSV >/dev/null 2>&1 &
sleep 5
echo "::                      FileServer started                      ::"
echo "::                                                              ::" 
echo "::                                                              ::" 
echo "::                      worldserver starting                    ::"
nohup ./world_server.sh >/dev/null 2>&1 &
sleep 5
echo "::                      worldserver started                     ::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::            JXMOBILE BY TOANDAIK SERVER STARTING            :::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"