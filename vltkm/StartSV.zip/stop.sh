#!/bin/sh

pkill -9 Server_NUMSV
pkill -9 FileServer_NUMSV

echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::            JXMOBILE BY TOANDAIK SERVER STOPED              :::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"

