#!/bin/sh

pkill -9 RankServer
pkill -9 GatewayX64
pkill -9 go-jxhttp
pkill -9 go-jxhttp_idip

echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::             JXMOBILE BY TOANDAIK GATE STOPED               :::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"

