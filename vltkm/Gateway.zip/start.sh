#!/bin/sh

echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::             JXMOBILE BY TOANDAIK GATE STARTING             :::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo "::                      go-jxhttp starting                      ::"
nohup ./gohttp.sh >/dev/null 2>&1 &
sleep 5
echo "::                      go-jxhttp started                       ::"
echo "::                                                              ::" 
echo "::                                                              ::" 
echo "::                      go-jxhttpip starting                    ::"
nohup ./gohttpip.sh >/dev/null 2>&1 &
sleep 5
echo "::                      go-jxhttpip started                     ::"
echo "::                                                              ::" 
echo "::                                                              ::" 
echo "::                      gateway  starting                       ::"
nohup ./GatewayX64 >/dev/null 2>&1 &
sleep 5
echo "::                      gateway started                         ::"
echo "::                                                              ::" 
echo "::                                                              ::" 
echo "::                      RankServer starting                     ::"
nohup ./RankServer >/dev/null 2>&1 &
sleep 5
echo "::                      RankServer started                      ::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::             JXMOBILE BY TOANDAIK GATE STARTING             :::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"