env GOTRACEBACK=crash nohup ./go-jxhttp > logs/gohttp.log
