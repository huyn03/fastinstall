env GOTRACEBACK=crash nohup ./go-jxhttp_idip > logs/gohttp-idip.log
