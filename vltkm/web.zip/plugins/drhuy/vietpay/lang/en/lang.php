<?php return [
    'plugin' => [
        'name' => 'Vietpay',
        'description' => ''
    ]
];