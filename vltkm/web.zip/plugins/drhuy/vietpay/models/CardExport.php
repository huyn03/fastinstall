<?php namespace Drhuy\Vietpay\Models;

class CardExport extends \Backend\Models\ExportModel
{
    public function exportData($columns, $sessionKey = null)
    {
        $items = Card::all();
        $items->each(function($item) use ($columns) {
            $item->addVisible($columns);
        });
        return $items->toArray();
    }
}