<?php namespace Drhuy\Vietpay\Models;

use Model;

/**
 * Model
 */
class Order extends Model
{
    use \October\Rain\Database\Traits\Validation;
    

    /**
     * @var string The database table used by the model.
     */
    public $table = 'drhuy_vietpay_orders';

    public $fillable = ['name', 'status_id', 'user_id'];

    /**
     * @var array Validation rules
     */
    public $rules = [
        'name'  => 'required|unique:drhuy_vietpay_orders,name',
        'user'  => 'required',
        'status'=> 'required'
    ];

    public $hasMany = [
        'cards'=> 'Drhuy\Vietpay\Models\Card'
    ];

    public $belongsTo = [
        'status'=> 'Drhuy\Vietpay\Models\Status',
        'user'=> 'Rainlab\User\Models\User',
    ];

    public function beforeValidate(){
        if(!$this-> name)
            $this-> name = str_random(8);
    }

    public function afterSave(){
        if(isset($this->original['status_id']) && $this->original['status_id'] != $this-> status_id)
            foreach ($this-> cards as $card) {
                if($this-> status_id != $card-> finish_status)
                    break;
                $card-> status_id = $this-> status_id;
                $card-> save();
            }
    }

    public function checkCardsStatus(){
        foreach ($this-> cards as $card) {
            $tmpStatus = $card-> status_id;
            if($card-> status_id != $card-> finish_status)
                break;
        }
        $this-> status_id = $tmpStatus;
        $this-> save();
    }
}
