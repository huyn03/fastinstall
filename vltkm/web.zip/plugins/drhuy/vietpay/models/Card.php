<?php namespace Drhuy\Vietpay\Models;

use Model;
use RainLab\User\Models\User;
use Drhuy\Vietpay\Classes\Helpers;
/**
 * Model
 */
class Card extends Model
{
    use \October\Rain\Database\Traits\Validation;
    
    /*
     * Disable timestamps by default.
     * Remove this line if timestamps are defined in the database table.
     */
    public $timestamps = false;

    public $process_status = 3;
    public $finish_status = 4;
    public $fail_status = 5;

    public $fillable = ['serial', 'code', 'telco_id', 'amount_id', 'user_id', 'status_id', 'type_id', 'sale_id'];
    /**
     * @var string The database table used by the model.
     */
    public $table = 'drhuy_vietpay_cards';

    /**
     * @var array Validation rules
     */
    public $rules = [
        'serial'    => 'numeric|digits_between:7,20|unique:drhuy_vietpay_cards,serial',
        'code'      => 'numeric|digits_between:7,20|unique:drhuy_vietpay_cards,code',
        'amount_id' => 'required|exists:drhuy_vietpay_amounts,id',
        'telco_id'  => 'required|exists:drhuy_vietpay_telcos,id',
        // 'order_id'  => 'exists:drhuy_vietpay_orders,id'
    ];

    public $customMessages = [
        '*.required'       => '[:attribute] không được bỏ trống!',
        '*.numeric'        => '[:attribute] phải là số!',
        '*.digits_between' => '[:attribute] lớn hơn :min và nhỏ hơn :max ký tự',
        '*.unique'         => '[:attribute] đã tồn tại',
        '*.exists'         => '[:attribute] không tồn tại!',
    ];

    public $belongsTo = [
        'telco'  => 'Drhuy\Vietpay\Models\Telco',
        'amount' => 'Drhuy\Vietpay\Models\Amount',
        'order'  => 'Drhuy\Vietpay\Models\Order',
        'status' => 'Drhuy\Vietpay\Models\Status',
    ];

    public function afterSave(){
        $this-> processData();
    }

    public function afterCreate(){
        $this-> processData();
    }

    private function processData(){
        if(isset($this->original['status_id']) && $this->original['status_id'] == $this-> status_id)
            return;
        if(!isset($this-> order-> user_id))
            return;

        $user = User::find($this-> order-> user_id);

        if(!$user)
            return;

        $old_status = $this->original['status_id']?? $this-> process_status;
        $new_status = $this->status_id;
        $amount = $this-> amount-> name;
        $sale = $this-> telco-> type-> sale;

        $nMoney = $amount * $sale;

        if($old_status != $this-> finish_status && $new_status == $this-> finish_status){
            $user-> d_money += $nMoney;
            $user-> save();
            \Flash::success("+$nMoney");
        }

        if($old_status == $this-> finish_status && $new_status != $this-> finish_status){
            $user-> d_money -= $nMoney;
            $user-> save();
            \Flash::success("-$nMoney");
        }

        // Helpers::writeLog("--- $nMoney ---\n", "card.log");

        $this-> order-> status_id = $this-> finish_status;
        foreach ($this->order-> cards as $card) {
            if ($card-> status_id != $this-> finish_status){
                $this-> order-> status_id = $card-> status_id;
                break;
            }
        }
        $this-> order-> save();
    }

    public function getSerialHideAttribute(){
        return Helpers::str_hide($this-> serial);
    }
    public function getCodeHideAttribute(){
        return Helpers::str_hide($this-> code);
    }
    public function getMoneyFormatAttribute(){
        $r = '';
        $amount = $this-> amount-> name;
        $sale = $this-> telco-> type-> sale;
        if($sale != 1){
            $r = $amount * ($sale - 1);
            $r = number_format($r);
            $r = " + ($r".'đ)';
        }
        return number_format($amount).'đ'. $r ;
    }

}
