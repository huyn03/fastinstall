<?php namespace Drhuy\Vietpay\Components;

use Cms\Classes\ComponentBase;
use RainLab\User\Facades\Auth;
use Drhuy\Vietpay\Models\Order;

class History extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'History',
            'description' => 'List history order'
        ];
    }

    private $user;

    public function defineProperties()
    {
        return [];
    }

    public function onRun(){
        $this-> user = Auth::getUser();
        if(!$this-> user)
            return;
        $this-> prepareVars();
    }

    public function prepareVars(){

        $this-> page['orders'] = Order::where('user_id', $this-> user-> id)-> orderBy('created_at', 'desc')-> limit(30)-> get();
        
    }

}
