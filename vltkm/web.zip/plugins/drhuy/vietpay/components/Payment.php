<?php namespace Drhuy\Vietpay\Components;

use Cms\Classes\ComponentBase;
use Drhuy\Vietpay\Models\Telco;
use Drhuy\Vietpay\Models\Amount;
use Drhuy\Vietpay\Models\Order;
use Drhuy\Vietpay\Models\Card;
use RainLab\User\Facades\Auth;
use Drhuy\Vietpay\Classes\Helpers;
use Drhuy\Vietpay\Classes\Securimage;

use Cms\Classes\Page;
use Cms\Classes\Partial;

class Payment extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Payment',
            'description' => 'Payment component'
        ];
    }

    public function defineProperties()
    {

        return [
            'page'=> [
                'title'         => 'Redirect to',
                'description'   => 'Redirect after pay success',
                'type'          => 'dropdown'
            ],
            'bankPartial'=> [
                'title'         => 'Load Bank Info',
                'description'   => 'Partial to bank info params (key, amount, sale)',
                'type'          => 'dropdown'
            ],
            'walletPartial'=> [
                'title'         => 'Load Wallet Info',
                'description'   => 'Partial to wallet info params (walletName, key, amount, sale)',
                'type'          => 'dropdown'
            ],
            'securimage'=> [
                'title'         => 'Securimage',
                'description'   => 'Use securimage captcha params(post["captcha"])',
                'type'          => 'dropdown',
                'options'       => ["Tắt", "Bật"],
                'default'       => 1
            ],
            'gamebankCharging'=> [
                'title'         => "Api Gamebank.vn",
                'type'          => "dropdown",
                'options'       => ["Tắt", "Bật"],
                'group'         => "Gamebank.vn"
            ],
            'merchant_id'=> [
                'title'         => 'Merchant_id',
                'group'         => "Gamebank.vn",
                'default'       => '74162'
            ],
            'api_user'=> [
                'title'         => 'Api_user',
                'group'         => "Gamebank.vn",
                'default'       => '5fdb518ccbc35'
            ],
            'api_password'=> [
                'title'         => 'Api_password',
                'group'         => "Gamebank.vn",
                'default'       => '40bc70975b52b4d9d39a040f57bb1c5b'
            ],
            'thesieureCharging'=> [
                'title'         => "Api Thesieure.com",
                'type'          => "dropdown",
                'options'       => ["Tắt", "Bật"],
                'group'         => "Thesieure.com"
            ],
            'partner_id'=> [
                'title'         => 'Partner_id',
                'group'         => "Thesieure.com",
                'default'       => '0280680061'
            ],
            'partner_key'=> [
                'title'         => 'Partner_key',
                'group'         => "Thesieure.com",
                'default'       => 'c28c5ff572c09d7f02ad89c480eed8d6'
            ],

        ];
    }

    public function getPageOptions(){
        return [''=>'- refresh page -'] + Page::sortBy('baseFileName')->lists('baseFileName', 'baseFileName');
    }
    public function getBankPartialOptions(){
        return [''=>'use default'] + Partial::sortBy('baseFileName')->lists('baseFileName', 'baseFileName');
    }

    public function getWalletPartialOptions(){
        return [''=>'use default'] + Partial::sortBy('baseFileName')->lists('baseFileName', 'baseFileName');
    }

    public function onRun(){
        $this-> prepareVars();
    }

    public function prepareVars(){
        $this-> page['card_telcos'] = Telco::where('status_id', 1)-> where('type_id', 1)-> get();
        $this-> page['bank_telcos'] = Telco::where('status_id', 1)-> where('type_id', 2)-> get();
        $this-> page['wallet_telcos'] = Telco::where('status_id', 1)-> where('type_id', 3)-> get();
        $this-> page['amounts'] = Amount::where('status_id', 1)-> get();
        $this-> page['redirect'] = $this-> property('page');
        $this-> page['securimagePath'] = $this-> property('securimage')? Helpers::paths('securimage'): null;
        $this-> page['path'] = Helpers::paths('plugin');
        $this-> page['auto_charging'] = !$this-> check_properties([
            'gamebankCharging', 'thesieureCharging'
        ], false);
    }

    public function onPayment(){

        if(!$this-> checkCaptcha()) return;

        Helpers::validation([
            'seri'      => 'required',
            'code'      => 'required',
        ]);

        $serial     = post('seri');
        $code       = post('code');
        $telco_id   = post('telco_id');
        $amount_id  = post('amount_id');

        if($this-> check_properties([
            'gamebankCharging', 'thesieureCharging'
        ], false)){
            $card = $this-> createCard($serial, $code, $telco_id, $amount_id);
            return $this-> redirect();
        }

        if($this-> gamebankCharging($serial, $code, $telco_id, $amount_id) ||
            $this-> thesieureCharging($serial, $code, $telco_id, $amount_id))
                return $this-> redirect();

    }

    public function onBankRequest(){

        if(!$this-> checkCaptcha()) return;

        $card = $this-> createCard('','', post('telco_id'), post('amount_id'), 2);
        if ($card)
            $bankPartial = $this-> property('bankPartial')?? "@_bank";
            return ['#request-brp' => $this->renderPartial($bankPartial, [
            'key'       => $card-> order-> name,
            'amount'    => $card-> amount-> name,
            'bankName'  => $card-> telco-> name,
            'sale'      => $card-> telco-> sale
        ])];
        return \Flash::error('Lỗi!');
    }

    public function onWalletRequest(){

        if(!$this-> checkCaptcha()) return;
        
        $card = $this-> createCard('','', post('telco_id'), post('amount_id'), 3);
        if ($card)
            $walletPartial = $this-> property('walletPartial')?? "@_wallet";
            return ['#request-wrp' => $this->renderPartial($walletPartial, [ 
                'key'       => $card-> order-> name,
                'amount'    => $card-> amount-> name,
                'walletName' => $card-> telco-> name,
                'sale'      => $card-> telco-> sale
            ])];
        return \Flash::error('Lỗi!');
    }

    private function createCard($serial, $code, $telco_id, $amount_id, $type_id = 1, $order_name = null, $order_description = null){
        $user = Auth::getUser();

        if (!$user)
            return;

        $card = Card::create([
            'serial'     => $serial,
            'code'       => $code,
            'telco_id'   => $telco_id,
            'amount_id'  => $amount_id
        ]);

        if ($card)
        {
            $order = Order::create([
                'status_id' => $card-> process_status,
                'user_id'   => $user-> id,
                'name'      => $order_name,
                'description'=> $order_description
            ]);

            $card-> status_id = $card-> process_status;
            $card-> order = $order;
            $card-> save();

            return $card;
        }

        return false;
    }

    private function gamebankCharging($serial, $code, $telco_id, $amount_id){
        
        if(!$this-> property('gamebankCharging'))
            return;

        $telco  = $telco_id;
        $amount = Amount::find($amount_id)-> name;
        $merchant_id    = $this-> property('merchant_id');
        $api_user       = $this-> property('api_user');
        $api_password   = $this-> property('api_password');
        $return = Helpers::gamebankCharging($serial, $code, $telco, $amount, '', $merchant_id, $api_user, $api_password);
        
        // test
        // $return = [
        //     'code'=> 6,
        //     'info_card'=> 20000
        // ];
        $szSite = "Gamebank";

        $card = null;

        if($return['code'] === 0 && $return['info_card'] >= 10000){
            #thẻ thành công
            $card = $this-> createCard($serial, $code, $telco_id, $amount_id);
            if($card)
                $this-> onChargingSuccess($card, $szSite);
        }elseif ($return['code'] === 6) {
            #thẻ chờ xử lý
            $card = $this-> createCard($serial, $code, $telco_id, $amount_id);
            if($card)
                $this-> onChargingWaiting($card, $szSite);
        }else{
            $this-> onChargingError($return['msg']);
        }
        return $card;
    }

    private function thesieureCharging($serial, $code, $telco_id, $amount_id){
        if(!$this-> property('thesieureCharging'))
            return;

        $telco = strtoupper(Telco::find($telco_id)-> name);
        $amount        = Amount::find($amount_id)-> name;
        $request_id    = str_random(8);
        $partner_id    = $this-> property('partner_id');
        $partner_key   = $this-> property('partner_key');

        $return = Helpers::thesieureCharging($telco, $code, $serial, $amount, $partner_id, $partner_key, $request_id);

        $szSite = "Thesieure";

        $card = null;

        if($return['status'] === 1){
            $card = $this-> createCard($serial, $code, $telco_id, $amount_id, 1, $request_id);
            if($card)
                $this-> onChargingSuccess($card, $szSite);
        }elseif($return['status'] === 99){
            $card = $this-> createCard($serial, $code, $telco_id, $amount_id, 1, $request_id);
            if($card)
                $this-> onChargingWaiting($card, $szSite);
        }else{
            $this-> onChargingError($return['message']);
        }
        
        return $card;
    }

    private function onChargingSuccess($card, $szSite){
        $card-> order-> description = "$szSite - Thành công!";
        $card-> order-> save();
        $card-> status_id = $card-> finish_status;
        $card-> save();
    }

    private function onChargingWaiting($card, $szSite){
        $card-> order-> description = "$szSite - Chờ xử lý!";
        $card-> order-> save();
    }

    private function onChargingError($message){
        \Flash::error($message." - thẻ chưa được lưu vào hệ thống! bạn có thể sử dụng bình thường!");
    }

    private function checkCaptcha(){
        $securimage = $this-> property('securimage');
        if($securimage){
            if(!post('captcha')){
                \Flash::error('Captcha không được bỏ trống!');
                return;
            }

            $namespace = post('namespace')?? '';
            $securimage = new Securimage(array('namespace' => $namespace));
            $captcha = @post('captcha');
            if(!$securimage->check($captcha)){
                \Flash::error("Captcha không đúng!");
                return;
            }
        }

        return true;
    }

    public function redirect(){
        $link_to = $this-> property('page');

        if ($link_to)
            return \Redirect::to($link_to);
        return \Redirect::refresh();
    }

    public function check_properties($properties, $has = false){
        foreach ($properties as $property) {
            if ($this-> property($property) != $has)
                return false;
        }
        return true;
    }

}
