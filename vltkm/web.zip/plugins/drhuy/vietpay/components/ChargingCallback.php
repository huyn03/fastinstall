<?php namespace Drhuy\Vietpay\Components;

use Cms\Classes\ComponentBase;
use Drhuy\Vietpay\Models\Card;
use Drhuy\Vietpay\Classes\Helpers;
// session_start();
// error_reporting(E_ALL^E_NOTICE);
// error_reporting(E_ERROR);

class ChargingCallback extends ComponentBase
{

    public $message;

    public function componentDetails()
    {
        return [
            'name'        => 'Charging Callback',
            'description' => 'Process charging callback request'
        ];
    }

    public function defineProperties()
    {
        return [
            'Gamebank'=> [
                'title'         => "Api Gamebank.vn",
                'type'          => "dropdown",
                'options'       => ["Tắt", "Bật"],
                'group'         => "Gamebank.vn"
            ],
            'GamebankKey'=> [
                'title'         => 'Gamebank Key',
                'type'          => 'text',
                'group'         => "Gamebank.vn",
                'default'       => 'gp5fdb518ccbca11608208780'
            ],
            'Thesieure'=> [
                'title'         => "Api Thesieure.com",
                'type'          => "dropdown",
                'options'       => ["Tắt", "Bật"],
                'group'         => "Thesieure.com"
            ],
            'ThesieureKey'=> [
                'title'         => 'Thesieure Key',
                'type'          => 'text',
                'group'         => "Thesieure.com",
                'default'       => 'c28c5ff572c09d7f02ad89c480eed8d6'
            ],
        ];
    }

    public function onRun(){
        if($this-> property('Gamebank'))
            $this-> gamebankChargingCallback();
        elseif($this-> property('Thesieure'))
            $this-> thesieureChargingCallback();
        else
            $this-> message = "Charging Callback";
    }

    public function thesieureChargingCallback(){
        $szSite = "Thesieure";

        // $data = Helpers::check_POST_attributes(['status', 'code', 'serial', 'declared_value', 'telco', 'trans_id', 'callback_sign', 'message']);
        $data = Helpers::check_GET_attributes(['status', 'code', 'serial', 'declared_value', 'telco', 'trans_id', 'callback_sign']);

        $checked = $data['checked'];
        $data = $data['data'];
        
        if($checked){
            $partner_key = $this-> property('ThesieureKey'); //Key cung cấp cho mỗi tài khoản   

            $checksum_gb = md5($partner_key.$data['code'].$data['serial']);
            
            if($data['callback_sign'] ==  $checksum_gb)
            {
                $card = Card::where('code', $data['code'])-> first();
                if($data['status'] == 1)
                    $this-> cardChargingSuccess($card, $data, $szSite);
                else
                    $this-> cardChargingError($card, $data, $szSite);
            }
            else
                $this-> keySecureError($data, $szSite);
        }
        else
            $this-> paramsError($data, $szSite);
    }

    public function gamebankChargingCallback(){
        $szSite = "Gamebank";
        $data = Helpers::check_GET_attributes(['status', 'seri', 'pin', 'price', 'tran_id', 'inote', 'checksum']);
        $checked = $data['checked'];
        $data = $data['data'];
        if($checked){
            $key = $this-> property('GamebankKey'); //Key Gamebank cung cấp cho mỗi tài khoản   

            $checksum_gb = hash('sha256',$data['status'] . $data['seri'] . $data['pin'] .  $data['price'] . $data['tran_id'] . $data['inote'] . $key);
            

            if($data['checksum'] ==  $checksum_gb)
            {
                $card = Card::where('code', $data['code'])-> first();
                if($data['status'] == '0')
                    $this-> cardChargingSuccess($card, $data, $szSite);
                else
                    $this-> cardChargingError($card, $data, $szSite);
            }
            else
                $this-> keySecureError($data, $szSite);
        }
        else
            $this-> paramsError($data, $szSite);
    }

    private function cardChargingSuccess($card, $params, $szSite){
        if($card){
            $card-> order-> description = "$szSite - Thành công!";
            $card-> status_id = $card-> finish_status;
            $card-> save();
            $message = "Nạp thành công: updated!";
            $this-> message = $message;
            return;
        }
        //Thẻ nạp thành công
        $logcontent = "The nap thanh cong: ".json_encode($params)."\n";
        Helpers::writeLog($logcontent, $szSite.'_success.log');
        $message = "Nạp thành công: writeLog!";
        $this-> message = $message;
    }

    private function cardChargingError($card, $params, $szSite){
            if($card){
                $message = $params['message']?? 'Thẻ sai';
                $card-> order-> description = "$szSite - $message!";
                $card-> status_id = $card-> fail_status;
                $card-> save();
                $message = "The nap that bai: updated!";
                $this-> message = $message;
                return;
            }
            //thẻ nạp không thành công
            $logcontent = "The nap that bai: ".json_encode($params)."\n";
            Helpers::writeLog($logcontent, $szSite.'_success.log');
            $message = "The nap that bai: writeLog!";
            $this-> message = $message;
    }

    private function keySecureError($params, $szSite){
        $logcontent = "Sai mã bảo mật: ".json_encode($params)."\n";
        Helpers::writeLog($logcontent, $szSite."_error.log");
        $message = "$szSite: Sai mã bảo mật cung cấp";
        $this-> message = $message;
    }

    private function paramsError($params, $szSite){
        $logcontent = "Khong du tham so: ".json_encode($params)."\n";
        Helpers::writeLog($logcontent, $szSite."_error.log");
        $message = "$szSite: Không đủ tham số!";
        $this-> message = $message;
    }

}
