<?php namespace Drhuy\Vietpay\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVietpayStatus extends Migration
{
    public function up()
    {
        Schema::create('drhuy_vietpay_status', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('name');
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_vietpay_status');
    }
}
