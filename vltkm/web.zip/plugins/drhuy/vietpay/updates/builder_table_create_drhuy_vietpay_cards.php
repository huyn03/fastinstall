<?php namespace Drhuy\Vietpay\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVietpayCards extends Migration
{
    public function up()
    {
        Schema::create('drhuy_vietpay_cards', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('serial')-> nullable();
            $table->string('code')-> nullable();
            $table->integer('telco_id')->nullable();
            $table->integer('amount_id')->nullable();
            $table->integer('status_id')->nullable();
            $table->integer('order_id')->unsigned()->nullable();
            $table->foreign('order_id')->references('id')->on('drhuy_vietpay_orders')->onDelete('set null');
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_vietpay_cards');
    }
}
