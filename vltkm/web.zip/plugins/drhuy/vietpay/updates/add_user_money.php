<?php namespace Drhuy\Vietpay\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;
use RainLab\User\Controllers\Users as UsersController;

class AddUserMoney extends Migration
{
    public function up()
    {
        Schema::table('users', function($table)
        {
            $table->integer('d_money')-> default(0);
        });
    }
    
    public function down()
    {
        Schema::table('users', function ($table) {
            $table->dropColumn('d_money');
        });
    }
}
