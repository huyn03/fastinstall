<?php namespace Drhuy\Vietpay\Updates;

use October\Rain\Database\Updates\Seeder;
use Drhuy\Vietpay\Models\Status;
use Drhuy\Vietpay\Models\Telco;
use Drhuy\Vietpay\Models\Amount;
use Drhuy\Vietpay\Models\Ttype;

class Seed extends Seeder
{
    public function run()
    {

        Status::insert([
            ['name'=> 'Hoạt động'],
            ['name'=> 'Ngừng hoạt động'],
            ['name'=> 'Đang xử lý'],
            ['name'=> 'Hoàn tất'],
            ['name'=> 'Thất bại'],
            ['name'=> 'Lỗi không xác định']
        ]);

        Ttype::insert([
            ['name'=> 'Card', 'sale'=> 0.9],
            ['name'=> 'Bank', 'sale'=> 1.25],
            ['name'=> 'Wallet', 'sale'=> 1.2],
        ]);

        Telco::insert([
            ['name'=> 'Viettel'     , 'status_id'=> 1, 'type_id'=> 1, 'sale_id'=> 1],
            ['name'=> 'Mobifone'    , 'status_id'=> 1, 'type_id'=> 1, 'sale_id'=> 1],
            ['name'=> 'Vinaphone'   , 'status_id'=> 1, 'type_id'=> 1, 'sale_id'=> 1],
            ['name'=> 'Gate'        , 'status_id'=> 2, 'type_id'=> 1, 'sale_id'=> 1],
            ['name'=> 'VTC (vcoin)' , 'status_id'=> 2, 'type_id'=> 1, 'sale_id'=> 1],
            ['name'=> 'Vietnammobi' , 'status_id'=> 1, 'type_id'=> 1, 'sale_id'=> 1],
            ['name'=> 'Zing'        , 'status_id'=> 2, 'type_id'=> 1, 'sale_id'=> 1],
            ['name'=> 'Bit'         , 'status_id'=> 2, 'type_id'=> 1, 'sale_id'=> 1],
            ['name'=> 'Megacard'    , 'status_id'=> 2, 'type_id'=> 1, 'sale_id'=> 1],
            ['name'=> 'Oncash'      , 'status_id'=> 2, 'type_id'=> 1, 'sale_id'=> 1],
            ['name'=> 'Bidv'        , 'status_id'=> 1, 'type_id'=> 2, 'sale_id'=> 2],
            ['name'=> 'Momo'        , 'status_id'=> 1, 'type_id'=> 3, 'sale_id'=> 2],
            ['name'=> 'Viettelpay'  , 'status_id'=> 1, 'type_id'=> 3, 'sale_id'=> 2],
            ['name'=> 'Zalopay'     , 'status_id'=> 1, 'type_id'=> 3, 'sale_id'=> 2]
        ]);

        Amount::insert([
            ['name'=> '10000', 'status_id'=> 1],
            ['name'=> '20000', 'status_id'=> 1],
            ['name'=> '50000', 'status_id'=> 1],
            ['name'=> '100000', 'status_id'=> 1],
            ['name'=> '200000', 'status_id'=> 1],
            ['name'=> '500000', 'status_id'=> 1],
        ]);

    }
}
