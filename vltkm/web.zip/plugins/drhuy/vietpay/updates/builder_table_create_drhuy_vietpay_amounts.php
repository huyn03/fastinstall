<?php namespace Drhuy\Vietpay\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVietpayAmounts extends Migration
{
    public function up()
    {
        Schema::create('drhuy_vietpay_amounts', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('name');
            $table->integer('status_id');
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_vietpay_amounts');
    }
}
