<?php namespace Drhuy\Vietpay\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVietpayTypes extends Migration
{
    public function up()
    {
        Schema::create('drhuy_vietpay_types', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('name');
            $table->string('sale')-> ddeffault(1);
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_vietpay_types');
    }
}
