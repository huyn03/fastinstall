<?php namespace Drhuy\Vietpay\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVietpayTecols extends Migration
{
    public function up()
    {
        Schema::create('drhuy_vietpay_telcos', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('name');
            $table->integer('status_id');
            $table->integer('type_id');
            $table->integer('sale_id');
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_vietpay_telcos');
    }
}
