<?php namespace Drhuy\Vietpay\Classes;

use Validator;
use ValidationException;

class Helpers
{
    public static $plugin_path = '/drhuy/vietpay/';

    public static $paths = [
        'plugin'=> '',
        'securimage'=> 'Secureimage'
    ];

    public static function paths($szkey){
        return static::$plugin_path.static::$paths[$szkey];
    }

	public static function str_hide($str){
		$len = strlen($str);
		if($len <= 3)
			return '...';
		return $str[0]."xxxxxxx".substr($str, $len - 3 , $len);

	}

    public static function validation($rules){

        $messages = [
            '*.required'=> "[:attribute] không được bỏ trống!",
        ];

        $validation = Validator::make(post(), $rules, $messages);
        if ($validation->fails()) {
            throw new ValidationException($validation);
        }
        return true;
    }
    /**
     * @Thesieure.com Charging
     */
    public static function thesieureCharging($telco, $code, $serial, $amount, $partner_id, $partner_key, $request_id, $command = 'charging'){

        $sign = md5("$partner_key$code$command$partner_id$request_id$serial$telco");
        $data = array(
            'telco'         => $telco,
            'code'          => $code,
            'serial'        => $serial,
            'amount'        => $amount,
            'request_id'    => $request_id,
            'partner_id'    => $partner_id,
            'command'       => $command,
            'sign'          => $sign,
        );

        $szUrl = "https://thesieure.com/chargingws/v2";
        
        $options = [];
        
        $result = static::crawl_data($szUrl, $data, null, $options);
        return [
            'status'    => $result->status,
            'message'   => $result->message
        ];
    }

    /**
     * @Gamebank.vn Charging
     */
    public static function gamebankCharging($seri,$pin,$card_type,$price_guest,$note,$merchant_id,$api_user,$api_password)
    {
        $data = array(
            'merchant_id'   => $merchant_id,
            'pin'           => $pin,
            'seri'          => $seri,
            'price_guest'   => $price_guest,
            'card_type'     => $card_type,
            'note'          => $note
        );

        $data_not_curl = [
            'merchant_id'   => $merchant_id,
            'api_user'      => $api_user,
            'api_password'  => $api_password,
            'pin'           => $pin,
            'seri'          => $seri,
            'card_type'     => intval($card_type),
            'price_guest'   => $price_guest,
            'note'          => urlencode($note),
        ];

        $szUrl = "http://sv.gamebank.vn/api/card2";
        
        $options = ['user'=> $api_user, 'password'=> $api_password];
        
        $result = static::crawl_data($szUrl, $data, $data_not_curl, $options);

        return [
            'code' => $result->code,
            'msg' => $result->msg,
            'info_card' => $result->info_card?? 0
        ];
    }

    public static function crawl_data($szUrl, $data, $data_not_curl = null, $options = []){
        if (function_exists('curl_version')) {
            $ch = curl_init($szUrl);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
            curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            if(isset($options['user']) && isset($options['password']))
                curl_setopt($ch, CURLOPT_USERPWD, $options['user'] . ":" . $options['password']);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            $result = curl_exec($ch);
        }else{
            $result = file_get_contents("$szUrl?".http_build_query($data_not_curl?? $data));   
            $result = str_replace("\xEF\xBB\xBF",'',$result);
        }
        return json_decode($result);
    }

    /**
     * @param array key
     * @$_GET
     * @return array
     */
    public static function check_POST_attributes($attrs){
        $data = [];
        $checked = true;
        foreach ($attrs as $attr) {
            if(!isset($_POST[$attr]))
                $checked = false;
            $data[$attr] = $_POST[$attr]?? null;
        }
        return ['checked'=> $checked, 'data'=> $data];
    }

    public static function check_GET_attributes($attrs){
        $data = [];
        $checked = true;
        foreach ($attrs as $attr) {
            if(!isset($_GET[$attr]))
                $checked = false;
            $data[$attr] = $_GET[$attr]?? null;
        }
        return ['checked'=> $checked, 'data'=> $data];
    }


    public static function writeLog($string, $filename) {
        $log_file = dirname(__FILE__) .'/../logs/'. $filename;        

        if ($fh = @fopen($log_file, "a+")) {
            fputs($fh, "$string \n", strlen($string));
            fclose($fh);
            return true;
        }
        else {
            return false;
        }
    }

}