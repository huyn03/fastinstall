<?php namespace Drhuy\Vietpay;

use System\Classes\PluginBase;
use RainLab\User\Controllers\Users as UsersController;
use Drhuy\Vietpay\Classes\Helpers;
use Drhuy\Vietpay\Classes\Securimage;

class Plugin extends PluginBase
{

    public $require = ['RainLab.User'];

    public function registerComponents()
    {
    	return [
            'Drhuy\Vietpay\Components\Payment'=> 'payment',
            'Drhuy\Vietpay\Components\ChargingCallback'=> 'chargingcallback',
            'Drhuy\Vietpay\Components\History'=> 'history',
    	];
    }

    public function registerSettings()
    {
    }

    public function boot(){
        UsersController::extendFormFields(function($form, $model, $context){     
            $form->addTabFields([
                'd_money' => [
                    'label'     => 'Money',
                    'type'      => 'text',
                    'span'      => 'auto',
                    'comment'   => 'd_money used by Vietpay plugin.',
                    'tab'       => 'Moneys'
                ],
            ]);

        });

        \Route::get(Helpers::paths('securimage'), function () {
            $img = new Securimage;
            if (!empty($_GET['namespace'])) $img->setNamespace($_GET['namespace']);
            $img-> show();
        });
    }
}
