<?php namespace Drhuy\Vietpay\Controllers;

use Backend\Classes\Controller;
use BackendMenu;
use Drhuy\Vietpay\Models\Order;

class Statistic extends Controller
{
    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('Drhuy.Vietpay', 'main-menu-item', 'side-menu-item5');
        $this-> vars = array_merge($this-> vars, $this-> init());
    }

    private function init(){

        $this-> pageTitle = "Statistic";
        $orders 	= Order::all();
        $finish 	= ['total'=> 0];
        $process 	= ['total'=> 0];
        $fail 		= ['total'=> 0];

        $cdate 	= strtotime(date('dmy'));
        $cday 	= date('d', $cdate);
        $cmonth = date('m', $cdate);
        $cyear 	= date('Y', $cdate);

		$process["$cmonth-$cyear"] = $process["$cmonth-$cyear"]?? ['total'=> 0];
		$finish["$cmonth-$cyear"]  = $finish["$cmonth-$cyear"]?? ['total'=> 0];
		$fail["$cmonth-$cyear"]	  = $fail["$cmonth-$cyear"]?? ['total'=> 0];

        foreach ($orders as $order) {
        	$date 	= strtotime($order-> created_at);
        	$day 	= date('d', $date);
        	$month 	= date('m', $date);
        	$year 	= date('Y', $date);

        	if(!isset($process["$month-$year"]))
    			$process["$month-$year"] = ['total'=> 0];
    		if(!isset($finish["$month-$year"]))
    			$finish["$month-$year"]	= ['total'=> 0];
    		if(!isset($fail["$month-$year"]))
    			$fail["$month-$year"] 	= ['total'=> 0];

    		if(!isset($process["$month-$year"]["$day"]))
    			$process["$month-$year"]["$day"] = 0;
    		if(!isset($finish["$month-$year"]["$day"]))
    			$finish["$month-$year"]["$day"] = 0;
    		if(!isset($fail["$month-$year"]["$day"]))
    			$fail["$month-$year"]["$day"] = 0;

        	foreach ($order-> cards as $card) {

        		$money = $card-> amount-> name?? 0;

        		switch ($card-> status_id) {
        			case $card-> finish_status: {
        				$finish['total'] 					+= $money;
						$finish["$month-$year"]['total'] 	+= $money;
						$finish["$month-$year"]["$day"] 	+= $money;
        				break;
					}
        			case $card-> process_status:{
	        			$process['total'] 					+= $money;
						$process["$month-$year"]['total'] 	+= $money;
						$process["$month-$year"]["$day"] 	+= $money;
						break;
					}
        			default: {
	        			$fail['total'] 					+= $money;
						$fail["$month-$year"]['total'] 	+= $money;
						$fail["$month-$year"]["$day"] 	+= $money;
        				break;
					}
        		}

        	}
        }

        return ['finish'=> $finish, 'fail'=> $fail, 'process'=> $process, 'cmonth'=> $cmonth, 'cyear'=> $cyear];
    }

    public function index(){
    }

    public function onChangeMonth(){
    	$key = post('selectKey') . "";
    	return ['#renderMonth'=> $this-> makePartial('renderMonth', ['cmonth'=> $key, 'cyear'=> ''])];
    }
}
