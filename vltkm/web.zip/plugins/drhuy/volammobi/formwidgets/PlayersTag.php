<?php namespace Drhuy\Volammobi\FormWidgets;

use Backend\Classes\FormWidgetBase;
use Drhuy\Volammobi\Classes\Volammobi;

/**
 * playersTag Form Widget
 */
class PlayersTag extends FormWidgetBase
{
    /**
     * @inheritDoc
     */
    protected $defaultAlias = 'playerstag';

    /**
     * @inheritDoc
     */
    public function init()
    {
    }

    /**
     * @inheritDoc
     */
    private $players = [];

    public function widgetDetails(){
        return [
            'name'=> 'Players Taglist',
            'description'=> 'Select players in game'
        ];
    }

    public function render()
    {
        $this->prepareVars();
        return $this->makePartial('playerstag');
    }

    /**
     * Prepares the form widget view data
     */
    public function prepareVars()
    {   
        $this->players = Volammobi::getPlayers();
        $this->vars['name'] = $this->formField->getName().'[]';
        $this->vars['players'] = $this-> preparePlayer();
        $this->vars['model'] = $this->model;
        $this->vars['selectedValues'] = $this-> getLoadValue()?? [];
    }

    public function preparePlayer(){
        $_players = [];
        foreach ($this-> players as $serverCode => $players) {
            if(is_array($players))
                foreach ($players as $player) {
                    $player['PlayerName']   = $player['PlayerName']." [".$player['Account']."]";
                    $player['Server'] = $serverCode;
                    $columns = $this-> formField-> getConfig('columns');
                    $values = [];
                    if(is_array($columns))
                    foreach ($columns as $column) {
                        $values[$column] = $player[$column];
                    }
                    $values = count($values)? json_encode($values): $player['ID'];
                    $_players[$values] = $player['PlayerName'];
                }
        }

        return $_players;
    }

    /**
     * @inheritDoc
     */
    public function loadAssets()
    {
        // $this->addCss('css/select2.min.css', 'drhuy.volammobi');
        // $this->addJs('js/select2.min.js', 'drhuy.volammobi');
    }

    /**
     * @inheritDoc
     */
    public function getSaveValue($value)
    {
        return $value;
    }
}
