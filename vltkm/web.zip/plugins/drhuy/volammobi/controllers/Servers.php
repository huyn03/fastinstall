<?php namespace Drhuy\Volammobi\Controllers;

use Backend\Classes\Controller;
use Drhuy\Volammobi\Models\Server;
use BackendMenu;

class Servers extends Controller
{
    public $implement = [        
    	'Backend\Behaviors\ListController',        
    	'Backend\Behaviors\FormController',        
    	'Backend\Behaviors\RelationController'  
    ];
    
    public $listConfig = 'config_list.yaml';
    public $formConfig = 'config_form.yaml';
    public $relationConfig = 'config_relation.yaml';

    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('Drhuy.Volammobi', 'main-menu-item', 'side-menu-item');
    }

    public function join(){
        $this-> pageTitle = "Gộp server";
        $this-> vars['servers'] = Server::all();
    }

    public function onJoin(){
        $server1 = post('server1');
        $server2 = post('server2');

        if($server1 == $server2){
            \Flash::error("2 server không được trùng nhau");
            return;
        }
        
        $server1 = Server::find($server1);
        $server2 = Server::find($server2);

        if(!$server1 || !$server2){\Flash::error("Lỗi! không tìm thấy server"); return;}

        if(!$server1-> db_id){\Flash::error("Lỗi! Không tìm thấy database server gốc"); return; }
        if(!$server2-> db_id){\Flash::error("Lỗi! Không tìm thấy database server cần lấy data"); return; }

        config()->set( 'database.connections.server1', [
            'driver'     => 'mysql',
            'engine'     => 'InnoDB',
            'host'       => $server1-> host,
            'port'       => $server1-> db_port,
            'database'   => $server1-> db_name,
            'username'   => $server1-> db_username,
            'password'   => $server1-> db_password,
            'charset'    => 'utf8mb4',
            'collation'  => 'utf8mb4_unicode_ci',
            'prefix'     => '',
            'varcharmax' => 191,
        ]);
        
        config()->set( 'database.connections.server2', [
            'driver'     => 'mysql',
            'engine'     => 'InnoDB',
            'host'       => $server2-> host,
            'port'       => $server2-> db_port,
            'database'   => $server2-> db_name,
            'username'   => $server2-> db_username,
            'password'   => $server2-> db_password,
            'charset'    => 'utf8mb4',
            'collation'  => 'utf8mb4_unicode_ci',
            'prefix'     => '',
            'varcharmax' => 191,
        ]);

        \Flash::success("Thành công!");
    }
}
