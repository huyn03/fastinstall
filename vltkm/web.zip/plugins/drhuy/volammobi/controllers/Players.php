<?php namespace Drhuy\Volammobi\Controllers;

use Backend\Classes\Controller;
use BackendMenu;
use Drhuy\Volammobi\Classes\Volammobi;

class Players extends Controller
{
    
    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('Drhuy.Volammobi', 'main-menu-item', 'side-menu-item3');
    }

    public function index(){
        $this-> pageTitle = "Nhân vật";
        $this-> vars['servers'] = Volammobi::getPlayers();
    }

    public function onPlayerGMAction(){
        $data = json_decode(post('_szPlayerAction'));
        $szRoleId = post('szRoleId');
        $code = post('szServerCode');
        $szAction = $data-> a;
        $content = isset($data-> content)? $data-> content : 1;
        $result = Volammobi::gameGM($code, $szAction, $content, $szRoleId);
        \Flash::success($result-> msg);

    }

}

