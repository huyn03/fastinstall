<?php namespace Drhuy\Volammobi\Controllers;

use Backend\Classes\Controller;
use BackendMenu;
use Drhuy\Volammobi\Classes\Volammobi;

class Players extends Controller
{
    
    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('Drhuy.Volammobi', 'main-menu-item', 'side-menu-item3');
    }

    public function index(){
        $this-> pageTitle = "Nhân vật";
        $this-> vars['servers'] = Volammobi::getPlayers();
    }

}

