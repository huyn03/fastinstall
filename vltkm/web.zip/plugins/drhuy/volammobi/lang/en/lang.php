<?php return [
    'plugin' => [
        'name' => 'volammobi',
        'description' => ''
    ]
];