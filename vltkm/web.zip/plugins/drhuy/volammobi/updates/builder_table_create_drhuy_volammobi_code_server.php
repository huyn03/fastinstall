<?php namespace Drhuy\Volammobi\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVolammobiCodeServer extends Migration
{
    public function up()
    {
        Schema::create('drhuy_volammobi_code_server', function($table)
        {
            $table->engine = 'InnoDB';
            $table->integer('code_id');
            $table->integer('server_id');
            $table->primary(['code_id','server_id']);
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_volammobi_code_server');
    }
}
