<?php namespace Drhuy\VoLamMobile\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVolammobileGcodes extends Migration
{
    public function up()
    {
        Schema::create('drhuy_volammobi_gcodes', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('name');
            $table->integer('code_id')-> unsigned()->nullable();
            $table->integer('qualty')->default(-1);
            $table->foreign('code_id')->references('id')->on('drhuy_volammobi_codes')->onDelete('cascade');
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_volammobi_gcodes');
    }
}
