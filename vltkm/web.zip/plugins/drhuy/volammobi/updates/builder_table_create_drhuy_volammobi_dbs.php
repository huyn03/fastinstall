<?php namespace Drhuy\Volammobi\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVolammobiDbs extends Migration
{
    public function up()
    {
        Schema::create('drhuy_volammobi_dbs', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('host')->nullable();
            $table->string('user')->nullable();
            $table->string('password')->nullable();
            $table->string('port')->nullable()->default('3306');
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_volammobi_dbs');
    }
}
