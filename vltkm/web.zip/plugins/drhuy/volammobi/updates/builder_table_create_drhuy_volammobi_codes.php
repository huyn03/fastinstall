<?php namespace Drhuy\VoLamMobile\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVolammobileCodes extends Migration
{
    public function up()
    {
        Schema::create('drhuy_volammobi_codes', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->text('name');
            $table->text('desc')        ->nullable();
            $table->text('players')     ->nullable();
            $table->text('used')        ->nullable();
            $table->dateTime('start')   ->nullable();
            $table->dateTime('end')     ->nullable();
            $table->integer('status_id')->nullable()->default(1);
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_volammobi_codes');
    }
}
