<?php namespace Drhuy\Volammobi\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddUserMoney extends Migration
{
    public function up()
    {
        Schema::table('users', function($table)
        {
            $table->integer('jxm_money')-> default(0);
        });
    }
    
    public function down()
    {
        Schema::table('users', function ($table) {
            $table->dropColumn('jxm_money');
        });
    }
}
