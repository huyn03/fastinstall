<?php namespace Drhuy\Volammobi\Updates;

use October\Rain\Database\Updates\Seeder;
use Drhuy\Volammobi\Models\Status;
use Drhuy\Volammobi\Models\SendItem;
use Drhuy\Volammobi\Models\Itemtype;

class Seed extends Seeder
{
    public function run()
    {

        Status::insert([
            ['name'=> 'Hoạt động'],
            ['name'=> 'Đang xử lý'],
            ['name'=> 'Hoàn tất'],
            ['name'=> 'Ngừng hoạt động'],
            ['name'=> 'Lỗi không xác định']
        ]);

        SendItem::insert([
            'title'=> "Administrator",
            'desc' => "Hệ thống thư tự động"
        ]);

        Itemtype::insert([
            ['name'=> 'Tiền tệ'],
            ['name'=> 'Trang bị'],
            ['name'=> 'Gia viên'],
            ['name'=> 'Đá hồn'],
            ['name'=> 'Đồng hành'],
            ['name'=> 'Vật phẩm'],
            ['name'=> 'Ngoại trang'],
            ['name'=> 'Ngựa'],
            ['name'=> 'Phi phong'],
            ['name'=> 'Thuốc lắc'],
            ['name'=> 'Danh hiệu'],
            ['name'=> 'Kiếm hiệp'],
        ]);

    }
}
