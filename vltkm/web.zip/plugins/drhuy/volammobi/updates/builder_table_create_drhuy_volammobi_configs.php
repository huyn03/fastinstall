<?php namespace Drhuy\Volammobi\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVolammobiConfigs extends Migration
{
    public function up()
    {
        Schema::create('drhuy_volammobi_configs', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('name');
            $table->string('value')-> nullable();
            $table->string('description')->nullable();
            $table->text('options')->nullable();
            $table->integer('parent_id')->nullable();
            $table->integer('nest_left')->nullable();
            $table->integer('nest_right')->nullable();
            $table->integer('nest_depth')->nullable();
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_volammobi_configs');
    }
}
