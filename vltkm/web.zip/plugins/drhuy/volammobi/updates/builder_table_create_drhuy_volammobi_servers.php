<?php namespace Drhuy\Volammobi\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVolammobiServers extends Migration
{
    public function up()
    {
        Schema::create('drhuy_volammobi_servers', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('name');
            $table->string('code')->nullable();
            $table->string('api')->nullable();
            $table->string('dbname')->nullable();
            $table->integer('db_id')->nullable();
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_volammobi_servers');
    }
}
