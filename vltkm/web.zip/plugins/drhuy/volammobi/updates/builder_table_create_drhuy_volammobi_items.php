<?php namespace Drhuy\Volammobi\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVolammobiItems extends Migration
{
    public function up()
    {
        Schema::create('drhuy_volammobi_items', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('key');
            $table->string('name');
            $table->integer('itemtype_id')-> nullable();
            $table->string('desc')->nullable();
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_volammobi_items');
    }
}
