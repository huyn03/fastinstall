<?php namespace Drhuy\Volammobi\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVolammobiCodeItem extends Migration
{
    public function up()
    {
        Schema::create('drhuy_volammobi_code_item', function($table)
        {
            $table->engine = 'InnoDB';
            $table->integer('code_id');
            $table->integer('item_id');
            $table->integer('qualty');
            $table->primary(['code_id','item_id']);
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_volammobi_code_item');
    }
}
