<?php namespace Drhuy\Volammobi\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVolammobiItemtypes extends Migration
{
    public function up()
    {
        Schema::create('drhuy_volammobi_itemtypes', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('name');
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_volammobi_itemtypes');
    }
}
