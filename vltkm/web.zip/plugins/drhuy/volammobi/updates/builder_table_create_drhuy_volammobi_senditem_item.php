<?php namespace Drhuy\Volammobi\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateDrhuyVolammobiSenditemItem extends Migration
{
    public function up()
    {
        Schema::create('drhuy_volammobi_senditem_item', function($table)
        {
            $table->engine = 'InnoDB';
            $table->integer('senditem_id');
            $table->integer('item_id');
            $table->integer('qualty')->default(1);
            $table->primary(['senditem_id','item_id']);
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('drhuy_volammobi_senditem_item');
    }
}
