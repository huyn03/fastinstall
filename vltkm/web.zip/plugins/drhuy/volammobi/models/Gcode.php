<?php namespace Drhuy\Volammobi\Models;

use Model;

/**
 * Model
 */
class Gcode extends Model
{
    use \October\Rain\Database\Traits\Validation;
    
    /*
     * Disable timestamps by default.
     * Remove this line if timestamps are defined in the database table.
     */
    public $timestamps = false;
 
    public $fillable = ['name', 'code_id', 'qualty'];

    /**
     * @var string The database table used by the model.
     */
    public $table = 'drhuy_volammobi_gcodes';

    /**
     * @var array Validation rules
     */
    public $rules = [
        'name'=> 'required|unique:drhuy_volammobi_gcodes,name'
    ];

    public $belongsTo = [
        'code'=> 'Drhuy\Volammobi\Models\Code'
    ];
}
