<?php namespace Drhuy\Volammobi\Models;

use Model;
use Drhuy\Volammobi\Classes\Volammobi;

/**
 * Model
 */
class SendItem extends Model
{
    use \October\Rain\Database\Traits\Validation;
    

    /**
     * @var string The database table used by the model.
     */
    public $table = 'drhuy_volammobi_senditems';

    /**
     * @var array Validation rules
     */
    public $rules = [
    ];

    public $jsonable = ['players'];

    private $_players = [];

    public $belongsToMany = [
        'items'=> [
            'Drhuy\Volammobi\Models\Item',
            'table'=> 'drhuy_volammobi_senditem_item',
            'key'=> 'senditem_id',
            'pivot'=> ['qualty']
        ]
    ];

    public function beforeSave(){

        if(!$this-> players)
        {
            \Flash::success('Chưa chọn nhân vật!');
            return false;
        }
        $msg = "";
        $items = Volammobi::itemsToPackageId($this-> items);
        foreach ($this-> players as $player) {
            $player= json_decode($player);
            $result = Volammobi::sendAward($player-> ID, $player-> Server, $items, $this-> title, $this-> desc);

            $_result = "Không kết nối với go-http";
            if($result != ""){
                $result = json_decode($result, true);
                $_result = isset($result['message'])? $result['message']: $_result;
                $_result = isset($result['msg'])? $result['msg']: $_result;
            }else $_result = "Lỗi request không tồn tại!";
            
            $name = $player-> PlayerName;
            $msg .= "$name: $_result | ";
        }

        $msg = substr($msg, 0, strlen($msg)- 3);
        \Flash::success($msg);
        return false;
    }
}
