<?php namespace Drhuy\Volammobi\Models;

use Model;
use Drhuy\Volammobi\Classes\Volammobi;
use Drhuy\Volammobi\Models\Server;

/**
 * Model
 */
class SendItem extends Model
{
    use \October\Rain\Database\Traits\Validation;
    

    /**
     * @var string The database table used by the model.
     */
    public $table = 'drhuy_volammobi_senditems';

    /**
     * @var array Validation rules
     */
    public $rules = [
    ];

    public $jsonable = ['players'];

    private $_players = [];

    public $belongsToMany = [
        'items'=> [
            'Drhuy\Volammobi\Models\Item',
            'table'=> 'drhuy_volammobi_senditem_item',
            'key'=> 'senditem_id',
            'pivot'=> ['qualty']
        ]
    ];

    public function beforeSave(){

        $items = Volammobi::itemsToPackageId($this-> items);
        if(!$this-> players)
        {
            foreach (Server::all() as $server) {
                $serverCode = $server-> code;
                $result = Volammobi::gameGM($serverCode, "SendRewardMailAll", $this-> desc, 1, $items);
            }
            \Flash::success('Đã gởi đến toàn bộ nhận vật!');
            return false;
        }
        $msg = "";
        foreach ($this-> players as $player) {
            $player= json_decode($player);
            $serverCode = isset($player-> Server)? $player-> Server : 10001;
            $result = Volammobi::gameGM($serverCode, $this-> title, $this-> desc, $player-> ID, $items);

            $_result = "Không kết nối với go-http";
            if($result){
                $_result = isset($result-> msg)? $result-> msg: $_result;
            }else $_result = "Lỗi request không tồn tại!";
            
            $name = $player-> PlayerName;
            $msg .= "$name: $_result | ";
        }

        $msg = substr($msg, 0, strlen($msg)- 3);
        \Flash::success($msg);
        return false;
    }
}
