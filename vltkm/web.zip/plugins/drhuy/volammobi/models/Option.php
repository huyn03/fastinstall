<?php namespace Drhuy\Volammobi\Models;

use Model;

/**
 * Model
 */
class Option extends Model
{
    use \October\Rain\Database\Traits\Validation;
    use \October\Rain\Database\Traits\NestedTree;
    
    /*
     * Disable timestamps by default.
     * Remove this line if timestamps are defined in the database table.
     */
    public $timestamps = false;

    public $jsonable = ["value"];

    /**
     * @var string The database table used by the model.
     */
    public $table = 'drhuy_volammobi_configs';

    /**
     * @var array Validation rules
     */
    public $rules = [
    ];

    public $belongsTo = [
        "parent"=> "Drhuy\Volammobi\Models\Option"
    ];

    public $hasMany = [
        "childs"=> ["Drhuy\Volammobi\Models\Option", "key"=> "parent_id"]
    ];

    public function beforeSave(){
        // $this-> description = $this-> description . " (".$this-> value.")";
    }
}
