<?php namespace Drhuy\Volammobi\Models;

use Model;

/**
 * Model
 */
class Item extends Model
{
    use \October\Rain\Database\Traits\Validation;
    
    /*
     * Disable timestamps by default.
     * Remove this line if timestamps are defined in the database table.
     */
    public $timestamps = false;

    public $fillable = ['key', 'name', 'itemtype_id'];


    /**
     * @var string The database table used by the model.
     */
    public $table = 'drhuy_volammobi_items';

    /**
     * @var array Validation rules
     */
    public $rules = [
        'key'=> 'required|unique:drhuy_volammobi_items,key'
    ];

    public $belongsTo = [
        'itemtype'=> 'Drhuy\Volammobi\Models\Itemtype'
    ];
}
