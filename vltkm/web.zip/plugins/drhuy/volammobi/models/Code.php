<?php namespace Drhuy\Volammobi\Models;

use Model;
use Drhuy\Volammobi\Classes\Volammobi;
/**
 * Model
 */
class Code extends Model
{
    use \October\Rain\Database\Traits\Validation;
    
    /*
     * Disable timestamps by default.
     * Remove this line if timestamps are defined in the database table.
     */
    public $timestamps = false;


    /**
     * @var string The database table used by the model.
     */
    public $table = 'drhuy_volammobi_codes';

    public $jsonable = ['players', 'used'];

    public $fillable = ['used'];

    /**
     * @var array Validation rules
     */
    public $rules = [
        'name'      => 'required',
        'status'    => 'required'

    ];

    public $belongsToMany = [
        'servers'=> [
            'Drhuy\Volammobi\Models\Server',
            'table'=> 'drhuy_volammobi_code_server'
        ],
        'items'=> [
            'Drhuy\Volammobi\Models\Item',
            'table'=> 'drhuy_volammobi_code_item',
            'pivot'=> ['qualty']
        ]
    ];

    public $hasMany = [
        'gcodes'=> ['Drhuy\Volammobi\Models\Gcode']
    ];

    public $belongsTo = [
        'status'=> ['Drhuy\Volammobi\Models\Status']
    ];

    public function getPlayersTags(){
        $players = json_decode(\Cookie::get('players'));
        return $players? array_column($players, 'ID', 'PlayerName'): [];
    }

    // dependsOn codes
    public function filterFields($fields, $context = null)
    {   
        $value = $fields-> _randomCodes-> value;
        if(!$value) return;
        $strs = explode('|',$value);
        if(!isset($strs[1]))
            $strs[1] = 1;
        $str = "";
        if(!$this-> id){
            \Flash::success('Vui lòng nhấn "create" trước');
            return;
        }
        $qlt = isset($strs[2])? (int)$strs[2]: 1;
        for($i = 0; $i < (int)$strs[1]; $i++){
            Gcode::create([
                'name'   => $this-> formatRandomCode($strs[0]), 
                'code_id'=> $this-> id,
                'qualty' => $qlt
            ]);
        }
        $this-> _codes = $this-> getCodesAttribute();
    }

    public function formatRandomCode($s){
        $str = "";
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
        for($i = 0; $i < strlen($s); $i++){
            if($s[$i] == 'x' || $s[$i] == 'X'){
                $index = rand(0, strlen($characters) - 1); 
                $str .= $characters[$index];
            }
            else {
                $str .= $s[$i];
            }
        }

        return $str;
    }

    public function getCodesAttribute(){
        return json_encode($this-> gcodes-> lists("name"));
    }
}
