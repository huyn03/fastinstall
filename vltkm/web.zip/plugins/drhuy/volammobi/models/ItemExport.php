<?php namespace Drhuy\Volammobi\Models;

class ItemExport extends \Backend\Models\ExportModel
{
    public function exportData($columns, $sessionKey = null)
    {
        $items = Item::all();
        $items->each(function($item) use ($columns) {
            $item->addVisible($columns);
        });
        return $items->toArray();
    }
}