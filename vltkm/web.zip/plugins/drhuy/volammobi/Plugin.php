<?php namespace Drhuy\Volammobi;

use System\Classes\PluginBase;
use RainLab\User\Controllers\Users as UsersController;

class Plugin extends PluginBase
{

	public $require = [
	    'Rainlab.User',
	];

    public function registerComponents()
    {
        return [
            'Drhuy\Volammobi\Components\ApiLogin'   => 'apilogin',
            'Drhuy\Volammobi\Components\ApiGiftcode'=> 'apigiftcode',
            'Drhuy\Volammobi\Components\ApiPayment' => 'apipayment',
            'Drhuy\Volammobi\Components\ApiOptions' => 'apioptions',
            'Drhuy\Volammobi\Components\Giftcodes'   => 'giftcode',
        ];
    }

    public function registerFormWidgets()
    {
        return [
            'Drhuy\Volammobi\FormWidgets\PlayersTag'=> [
                'label' => 'Players',
                'code'  => 'playerstag'
            ]
        ];
    }

    public function boot(){
    }
}
