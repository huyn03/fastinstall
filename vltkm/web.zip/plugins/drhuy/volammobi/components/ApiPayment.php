<?php namespace Drhuy\Volammobi\Components;

use Cms\Classes\ComponentBase;
use Drhuy\Volammobi\Classes\Volammobi;

class ApiPayment extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Api payment',
            'description' => 'Game Payment API'
        ];
    }

    public function defineProperties()
    {
        return [];
    }

    public function onRun(){
        $data = json_decode(base64_decode(get('data')), true);
        $this-> page['result'] = Volammobi::payment($data);
    }
}
