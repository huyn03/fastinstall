<?php namespace Drhuy\Volammobi\Components;

use Cms\Classes\ComponentBase;
use Drhuy\Volammobi\Models\Code as Giftcode;

class Giftcodes extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Giftcode List',
            'description' => 'Get Giftcodes'
        ];
    }

    public function defineProperties()
    {
        return [];
    }

    public function onRun(){
        $this-> page['giftcodes'] = Giftcode::where('status_id', 1)-> get();
    }

    public function test(){
        echo "abc";
    }
}
