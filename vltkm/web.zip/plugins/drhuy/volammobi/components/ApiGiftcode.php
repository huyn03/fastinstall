<?php namespace Drhuy\Volammobi\Components;

use Cms\Classes\ComponentBase;
use Drhuy\Volammobi\Classes\Volammobi;

class ApiGiftcode extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Api Giftcode',
            'description' => 'Game Api Giftcode'
        ];
    }

    public function defineProperties()
    {
        return [];
    }

    public function onRun(){
        $data = json_decode(base64_decode(get('data')), true);
        $roleId     = $data['roleId'];
        $account    = $data['account'];
        $name       = $data['roleName'];
        $serverId   = $data['serverId'];
        $giftcode   = $data['giftcode'];
        $result = Volammobi::giftcode($roleId, $name, $account, $serverId, $giftcode);
        // $result = Volammobi::giftcode('1111114', 'admin', 'aaaa', '10001', 'test');
        $this-> page['result'] = $result;
    }
}
