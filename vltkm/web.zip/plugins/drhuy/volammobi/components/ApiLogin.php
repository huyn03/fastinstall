<?php namespace Drhuy\Volammobi\Components;

use Cms\Classes\ComponentBase;
use Drhuy\Volammobi\Classes\Volammobi;

class ApiLogin extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Api Login',
            'description' => 'Api gateway login'
        ];
    }

    public function defineProperties()
    {
        return [];
    }

    public function onRun(){
        $data = json_decode(base64_decode(get('authInfo')), true);
        $username   = $data['account'];
        $password   = $data['password'];
        $result = Volammobi::login($username, $password);
        $this-> page['result'] = $result;
    }
}
