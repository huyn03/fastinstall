<?php namespace Drhuy\Volammobi\Components;

use Cms\Classes\ComponentBase;
use Drhuy\Volammobi\Models\Option;

class ApiOptions extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Api Options',
            'description' => 'render options as json'
        ];
    }

    public function defineProperties()
    {
        return [];
    }

    public function onRun(){
        $this-> page['options'] = Option::whereNull("parent_id")-> get();
    }

}
