<?php namespace Drhuy\Volammobi\Classes;

class GameDef {

	private static $defs = [
		"Boss"=> [
			"nTimeDuration"		=> 12 * 60,
			"nPlayerEnterLevel"	=> 20,
			"nFinishWaitTime"	=> 5,
			"tbKinRewardRankScore"=> [
				"szAction"		=> "set",
				"szSortKey"		=> "TimeFrame",
				"szUpdateKey"	=> "tbRankScore",
				"tbForAll"=> [
					["Rank" => 1, "Score" => 120000],
					["Rank" => 2, "Score" => 100000],
					["Rank" => "math.huge", "Score" => 40000],
				]
			],
			"KinPrestigeRward" => [
				"szAction"		=> "set",
				["Rank" => 1, "Prestige" => 100],
				["Rank" => 2, "Prestige" => 90],
				["Rank" => "math.huge", "Prestige" => 1],
			],
			"szAwardMoneyType"=> "Gold",
			"tbPlayerBoxRankScore"=> [
				"szAction"		=> "set",
				["Rank" => 1, "Honor" => 1000],
				["Rank" => 2, "Honor" => 900],
				["Rank" => "math.huge", "Honor" => 100],
			],
			"tbKinBoxRankScore"=> [
				"szAction"		=> "set",
				["Rank" => 1, "Honor" => 1000],
				["Rank" => 2, "Honor" => 900],
				["Rank" => "math.huge", "Honor" => 100],
			],
			"tbAuctionRewards"=> [
				"szAction"		=> "append",
				"szSortKey"		=> "TimeFrame",
				"szUpdateKey"	=> "Rewards",
				"tbForAll"=> [
					["Rank" => 1, "Score" => 120000],
					["Rank" => 2, "Score" => 100000],
					["Rank" => "math.huge", "Score" => 40000],
				]
			],
		]
	];

	public static function get($szKey = null){
		return isset(static::$defs[$szKey])? static::$defs[$szKey] : static::$defs;
	}
}