<?php namespace Drhuy\Volammobi\Classes;

use RainLab\User\Facades\Auth;
use RainLab\User\Models\User;
use Drhuy\Volammobi\Models\Gcode;
use Drhuy\Volammobi\Models\Server;
use Drhuy\Volammobi\Models\Player;
/**
 * 
 */
class Volammobi
{   
    public static function getPlayers(){
        $servers = Server::all();
        $data = [];
        foreach ($servers as $server) {
            $players = [];
            if ($server-> api)
                $players = self::getPlayersFromApi($server-> api);
            elseif ($server-> dbname && $server-> db)
                $players = self::getPlayersFromDb($server-> dbname, $server-> db);
            else
                continue;
            $data[$server-> code] = $players;
        }
        return $data;
    }

    public static function getPlayersFromApi($url){
        return GlobalMethods::readUrl($url);
    }
    public static function getPlayersFromDb($dbname, $db){
        config()->set( 'database.connections.server', [
            'driver'     => 'mysql',
            'engine'     => 'InnoDB',
            'host'       => $db-> host,
            'port'       => $db-> port,
            'database'   => $dbname,
            'username'   => $db-> user,
            'password'   => $db-> password,
            'charset'    => 'utf8mb4',
            'collation'  => 'utf8mb4_unicode_ci',
            'prefix'     => '',
            'varcharmax' => 191,
        ]);

        return Player::rightjoin('player_query_data', 'ID','=','RoleId')-> get()-> toArray();

    }

    public static function login($username, $password) {
        $result = [
            ['code'=>'0'],//, 'msg'=> 'Đăng nhập thành công'],
            ['code'=>'1'],//, 'msg'=> 'Sai tài khoản hoặc mật khẩu'],
            ['code'=>'2'],//, 'msg'=> 'Tài khoản chưa kích hoạt'],
            ['code'=>'3'],//, 'msg'=> 'User không tìm thấy'],
        ];
        $r = 0;
        try {
            Auth::authenticate(['login' => $username, 'password' => $password]);
        }
        catch(\October\Rain\Auth\AuthException $e) {
            $authMessage = $e->getMessage();
            if (strrpos($authMessage, 'hashed credential') !== false) {
                $r = 1;
            } elseif (strrpos($authMessage, 'not activated') !== false) {
                $r = 2;
            } elseif (strrpos($authMessage, 'user was not found') !== false) {
                $r = 3;
            } else {
                $r = 3;
            }
        }
        return $r;
    }

    public static function payment($data) {
        $data['xu'] = $data['productUnitPrice'];
        $data['tradeNo'] = md5($data['account'].time());
        $data['payStatus'] = 1;

        $user = User::where('username', $data['account'])-> first();

        if($user){
            if($user-> d_money >= $data['totalAmount']){
                $user-> d_money -= $data['totalAmount'];
                $user-> save();
                $data['payStatus'] = 0;
            }else{
                $money = number_format($user-> d_money);
                $deepmoney = number_format($data['totalAmount'] - $user-> d_money);
                $data['msg'] = "Tài khoản còn lại: [ffff00]${money}vnđ [ffffff]còn thiếu [ff8100]${deepmoney}vnđ
[00d4c0]NẠP THÊM TIỀN NGAY";
            }
        }else{
            $data['msg'] = 'Lỗi tài khoản! vui lòng đăng nhập lại';
        }

        return $data;
    }


    public static function giftcode($roleid, $name, $account, $serverCode, $gCode) {
        $result = [
           'Code không tồn tại',
           'Code đã hết lượt sử dụng',
           'Code đã ngừng hoạt động',
           'Code chưa tới thời gian sử dụng',
           'Code đã quá thời gian sử dụng',
           'Code không được hổ trợ server này',
           'Nhân vật không sử dụng được code này!',
           'Nhân vật đã sử dụng code này!',
           'Thành công!',
           'Lỗi không xác định!'
        ];        

        $gcode = Gcode::where('name', $gCode)->first();

        if (!$gcode) return $result[0];
        
        if (!$gcode->qualty) return $result[1];
        
        $code = $gcode->code;

        if (!$code || $code->status_id != 1) return $result[2];
        
        $dnow = new \DateTime('NOW');
        $dstart = new \DateTime($code->start);
        $dend = new \DateTime($code->end);
        if ($code->start && $dstart > $dnow) return $result[3];
        if ($code->end && $dend < $dnow) return $result[4];
        
        if (isset($code->servers[0])) {
            if (!$code->servers->where('code', $serverCode)->first()) return $result[5];
        }

        if (isset($code->players)) {
            if (!in_array($roleid, $code->players))
                return $result[6];
        }

        if (gettype($code->used)== 'array') {
            if (in_array($roleid, $code->used))
                return $result[7];
            $code->used = array_merge($code->used, ["$roleid"]);
        }else{
            $code-> used = ["$roleid"];
        }

        $code-> save();

        $gcode-> qualty -= 1;
        $gcode-> save();

        try{
            $items = self::itemsToPackageId($code-> items);
            self::sendAward($roleid, $serverCode, $items, $code-> name, $code-> desc);
        }catch(Exception $e){
            return $result[9];
        }

        return $result[8];
    }

    public static function itemsToPackageId($items){
        $packageId = "";
        foreach ($items as $item) {
            $packageId .= is_numeric($item-> key)? "item,": "";
            $packageId .= "{$item-> key},{$item-> pivot-> qualty};";
        }
        return rtrim($packageId, ";");
    }

    public static function sendAward($roleid, $serverCode, $packageId, $title="", $content=""){

        $serialNo = time() + rand();
        $params = [
            'userId'        => 1,
            'roleId'        => $roleid,
            'serverCode'    => $serverCode,
            'serialNo'      => $serialNo,
            'packageId'     => $packageId,
            'title'         => $title,
            'content'       => $content,
        ];

        $url = "http://127.0.0.1:8088/efunsendreward?". http_build_query($params);
        $result = @file_get_contents($url);
        
        // $ch = curl_init();
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // curl_setopt($ch, CURLOPT_URL, $url);
        // $result = curl_exec($ch);
        // curl_close($ch);
        return $result;
    }


    public static function writeLog($data, $filename='test.txt'){
        $file = fopen($filename, "w");
        fwrite($file, $data);
        fclose($file);
    }

}