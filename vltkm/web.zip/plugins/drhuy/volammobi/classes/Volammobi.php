<?php namespace Drhuy\Volammobi\Classes;

use RainLab\User\Facades\Auth;
use RainLab\User\Models\User;
use Drhuy\Volammobi\Models\Gcode;
use Drhuy\Volammobi\Models\Server;
use Drhuy\Volammobi\Models\Player;
use Drhuy\Volammobi\Classes\GameDef;
/**
 * 
 */
class Volammobi
{   

    public static $gmActions = [
            '{"a":"WhiteTigerFuben"}'       => "Bạch hổ đường",
            '{"a":"Boss"}'                  => "Minh chủ võ lâm",
            '{"a":"KinTrainMgr"}'           => "Thí luyện bang hội",
            '{"a":"StartKinEscort"}'        => "Vận tiêu bang hội",
            '{"a":"Battle", "content": "1"}'   => "Tống kim",
            '{"a":"BossLeader1"}'           => "Thủ lĩnh dã ngoại",
            '{"a":"BossLeader"}'            => "Danh tướng",
            '{"a":"Auction", "content": "1"}'  => "Đấu giá hành cước",
            // "UpdateDef"         => "Cập nhật Def",
    ];

    public static $gmPlayerActions = [
        '{"a":"BanPlayer"}'                     => "Khóa tài khoản",
        '{"a":"UnBanPlayer"}'                   => "Mở khóa tài khoản",
        '{"a":"ClearBag"}'                      => "Xóa hành trang",
        '{"a":"BuyInvest", "content": "1"}'     => "Mua gói đầu tư",
        '{"a":"BuyDaysCard", "content": "7"}'   => "Mua gói 7 ngày",
        '{"a":"BuyDaysCard", "content": "30"}'  => "Mua gói 30 ngày",
        '{"a":"Auction", "content": "2"}'         => "Mở đấu giá bang",
        '{"a":"SetLevel","content": "59"}'        => "Đặt lại lv 59",
        '{"a":"AddLevel","content": "3"}'         => "Thêm 3 cấp",
    ];

    public static function getszGMActions(){
        $_gmAction = static::$gmActions;
        $result = "<div class='form-group text-field span-left'><select class='form-control custom-select select2-hidden-accessible' name='_szAction'>";
        foreach ($_gmAction as $key => $value) {
            $result .= "<option value='$key'>$value</option>";
        }
        $result .= '</select></div><div class="gameMethod-btn form-group text-field span-right"><button type="submit" data-request="onGameRequestOn" class="btn btn-primary" data-disposable="">Mở hoạt động</button><button type="submit" data-request="onGameRequestOff" class="btn btn-second" data-disposable="">Đóng hoạt động</button></div>';
        return $result;
    }

    public static function getszPlayerGMActions(){
        $_gmAction = static::$gmPlayerActions;
        $result = "<select name='_szPlayerAction'>";
        foreach ($_gmAction as $key => $value) {
            $result .= "<option value='$key'>$value</option>";
        }
        $result .= '</select><button data-request="onPlayerGMAction">Thực hiện</button>';
        return $result;
    }

    public static function doPlayerGM($serverCode, $params){
        $data = json_decode($params-> _szPlayerAction);
        $szRoleId = $params-> szRoleId;
        $szAction = $data-> a;
        $content = isset($data-> content)? $data-> content : 1;
        $result = static::gameGM($serverCode, $szAction, $content, $szRoleId);
    }

    public static function getPlayers(){
        $servers = Server::all();
        $data = [];
        foreach ($servers as $server) {
            $players = [];
            // if ($server-> api)
            //     $players = self::getPlayersFromApi($server-> api);
            // else
            if ($server-> dbname && $server-> db)
                $players = self::getPlayersFromDb($server-> dbname, $server-> db);
            else
                continue;
            $data[$server-> code] = $players;
        }
        return $data;
    }

    public static function getPlayersFromApi($url){
        return GlobalMethods::readUrl($url);
    }

    public static function getPlayersFromDb($dbname, $db){
        if (!$db) return;
        config()->set( 'database.connections.server', [
            'driver'     => 'mysql',
            'engine'     => 'InnoDB',
            'host'       => $db-> host,
            'port'       => $db-> port,
            'database'   => $dbname,
            'username'   => $db-> user,
            'password'   => $db-> password,
            'charset'    => 'utf8mb4',
            'collation'  => 'utf8mb4_unicode_ci',
            'prefix'     => '',
            'varcharmax' => 191,
        ]);
        try{
            return Player::rightjoin('player_query_data', 'ID','=','RoleId')-> get()-> toArray();
        } catch(\Illuminate\Database\QueryException $ex){
            return $ex->getMessage();
        }
    }

    public static function gameGM($serverCode, $szAction, $content = 1, $roleId = 1, $packageId="", $userId = 1){
        $szUrl = "http://127.0.0.1:8088";
        $ctx = stream_context_create(array('http'=>
            array(
                'timeout' => 0.5,  //1200 Seconds is 20 Minutes
            )
        ));
         $params = [
            'userId'        => $userId,
            'roleId'        => $roleId,
            'serverCode'    => $serverCode,
            'serialNo'      => rand(),
            'packageId'     => $packageId,
            'title'         => $szAction,
            'content'       => $content,
        ];
        // $serialNo = rand();
        // $szUrl = "$szUrl/efunsendreward?userId=1&roleId=$roleId&serverCode=$serverCode&serialNo=$serialNo&title=$szAction&content=$content";

        $szUrl = "$szUrl/efunsendreward?". http_build_query($params);
        // dump($szUrl);
        return json_decode(@file_get_contents($szUrl, false, $ctx));
        // return $szUrl;
    }

    public static function getDefs($szKey = null){
        return json_encode(GameDef::get($szKey));
    }

    public static function gameDefGM($serverCode, $szKey = null){
        $defs = json_encode(GameDef::get($szKey));
        return gameGM($serverCode, "UpdateDef", $defs);
    }

    public static function login($username, $password) {
        $result = [
            ['code'=>'0'],//, 'msg'=> 'Đăng nhập thành công'],
            ['code'=>'1'],//, 'msg'=> 'Sai tài khoản hoặc mật khẩu'],
            ['code'=>'2'],//, 'msg'=> 'Tài khoản chưa kích hoạt'],
            ['code'=>'3'],//, 'msg'=> 'User không tìm thấy'],
        ];
        $r = 0;
        try {
            Auth::authenticate(['login' => $username, 'password' => $password]);
        }
        catch(\October\Rain\Auth\AuthException $e) {
            $authMessage = $e->getMessage();
            if (strrpos($authMessage, 'hashed credential') !== false) {
                $r = 1;
            } elseif (strrpos($authMessage, 'not activated') !== false) {
                $r = 2;
            } elseif (strrpos($authMessage, 'user was not found') !== false) {
                $r = 3;
            } else {
                $r = 3;
            }
        }
        return $r;
    }

    public static function payment($data) {
        $data['xu'] = $data['productUnitPrice'];
        $data['tradeNo'] = md5($data['account'].time());
        $data['payStatus'] = 1;

        $user = User::where('username', $data['account'])-> first();

        if($user){
            if($user-> d_money >= $data['totalAmount']){
                $user-> d_money -= $data['totalAmount'];
                $user-> save();
                $data['payStatus'] = 0;
            }else{
                $money = number_format($user-> d_money);
                $deepmoney = number_format($data['totalAmount'] - $user-> d_money);
                $data['msg'] = "Tài khoản còn lại: [ffff00]${money}vnđ [ffffff]còn thiếu [ff8100]${deepmoney}vnđ
[00d4c0]NẠP THÊM TIỀN NGAY";
            }
        }else{
            $data['msg'] = 'Lỗi tài khoản! vui lòng đăng nhập lại';
        }

        return $data;
    }


    public static function giftcode($roleid, $name, $account, $serverCode, $gCode) {
        $result = [
           'Code không tồn tại',
           'Code đã hết lượt sử dụng',
           'Code đã ngừng hoạt động',
           'Code chưa tới thời gian sử dụng',
           'Code đã quá thời gian sử dụng',
           'Code không được hổ trợ server này',
           'Nhân vật không sử dụng được code này!',
           'Nhân vật đã sử dụng code này!',
           'Thành công!',
           'Lỗi không xác định!'
        ];        

        $gcode = Gcode::where('name', $gCode)->first();

        if (!$gcode) return $result[0];
        
        if (!$gcode->qualty) return $result[1];
        
        $code = $gcode->code;

        if (!$code || $code->status_id != 1) return $result[2];
        
        $dnow = new \DateTime('NOW');
        $dstart = new \DateTime($code->start);
        $dend = new \DateTime($code->end);
        if ($code->start && $dstart > $dnow) return $result[3];
        if ($code->end && $dend < $dnow) return $result[4];
        
        if (isset($code->servers[0])) {
            if (!$code->servers->where('code', $serverCode)->first()) return $result[5];
        }

        if (isset($code->players)) {
            if (!in_array($roleid, $code->players))
                return $result[6];
        }

        if (gettype($code->used)== 'array') {
            if (in_array($roleid, $code->used))
                return $result[7];
            $code->used = array_merge($code->used, ["$roleid"]);
        }else{
            $code-> used = ["$roleid"];
        }

        $code-> save();

        $gcode-> qualty -= 1;
        $gcode-> save();

        try{
            $items = self::itemsToPackageId($code-> items);
            self::sendAward($roleid, $serverCode, $items, $code-> name, $code-> desc);
        }catch(Exception $e){
            return $result[9];
        }

        return $result[8];
    }

    public static function itemsToPackageId($items){
        $packageId = "";
        foreach ($items as $item) {
            $packageId .= is_numeric($item-> key)? "item,": "";
            $packageId .= "{$item-> key},{$item-> pivot-> qualty};";
        }
        return rtrim($packageId, ";");
    }

    public static function writeLog($data, $filename='test.txt'){
        $file = fopen($filename, "w");
        fwrite($file, $data);
        fclose($file);
    }

}