<?php namespace Drhuy\Volammobi\Classes;

/**
 * 
 */
class GlobalMethods
{
	
	public static function readUrl($url){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_URL, $url);
		$result = curl_exec($curl);
		curl_close($curl);

		return json_decode($result, true);
	}

	public static function readUrls($urls){

		$curl = curl_init();
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		$result = [];
		foreach ($urls as $url) {
			curl_setopt($curl, CURLOPT_URL, $url);
			$_result = curl_exec($curl);
			array_push($result, json_decode($_result, true));
		}
		curl_close($curl);

		return $result;
	}

}