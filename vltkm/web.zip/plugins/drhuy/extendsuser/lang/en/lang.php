<?php return [
    'plugin' => [
        'name' => 'extendsUser',
        'description' => ''
    ]
];