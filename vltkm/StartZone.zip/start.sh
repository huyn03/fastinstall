#!/bin/sh

echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::            JXMOBILE BY TOANDAIK ZONE STARTING              :::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo "::                      FileServer starting                     ::"
nohup ./ZoneFileServer >/dev/null 2>&1 &
sleep 5
echo "::                      FileServer started                      ::"
echo "::                                                              ::" 
echo "::                                                              ::" 
echo "::                      worldserver starting                    ::"
nohup ./world_server.sh >/dev/null 2>&1 &
sleep 5
echo "::                      worldserver started                     ::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::            JXMOBILE BY TOANDAIK ZONE STARTING              :::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"