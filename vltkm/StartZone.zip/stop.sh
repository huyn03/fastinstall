#!/bin/sh

pkill -9 ZoneServer
pkill -9 ZoneFileServer

echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::              JXMOBILE BY TOANDAIK ZONE STOPED              :::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"

